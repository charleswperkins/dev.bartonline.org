<?php

/**
 * @file
 * The theme settings functions.
 */

require_once dirname(__FILE__) . '/includes/fortytwo_admin.inc';
require_once dirname(__FILE__) . '/includes/theme-settings-general.inc';
