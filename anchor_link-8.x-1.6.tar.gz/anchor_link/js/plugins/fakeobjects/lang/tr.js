/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'tr', {
	anchor: 'Bağlantı',
	flash: 'Flash Animasyonu',
	hiddenfield: 'Gizli Alan',
	iframe: 'IFrame',
	unknown: 'Bilinmeyen Nesne'
} );
